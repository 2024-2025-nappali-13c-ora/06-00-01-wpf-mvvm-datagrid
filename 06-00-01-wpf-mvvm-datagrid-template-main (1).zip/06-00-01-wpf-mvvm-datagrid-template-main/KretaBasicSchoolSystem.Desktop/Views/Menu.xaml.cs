﻿using System.Windows.Controls;


namespace KretaBasicSchoolSystem.Desktop.Views
{
    /// <summary>
    /// Interaction logic for MenuButtons.xaml
    /// </summary>
    public partial class Menu : UserControl
    {
        public Menu()
        {
            InitializeComponent();
        }
    }
}
