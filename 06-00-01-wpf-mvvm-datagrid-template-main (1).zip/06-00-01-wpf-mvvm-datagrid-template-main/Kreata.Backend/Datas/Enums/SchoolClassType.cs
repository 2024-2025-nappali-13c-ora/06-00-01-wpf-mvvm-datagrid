﻿namespace Kreata.Backend.Datas.Enums
{
    public enum SchoolClassType { ClassA, ClassB, ClassC }
}
